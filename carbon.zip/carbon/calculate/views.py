from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home_view(request, *args , **kwargs):
	return render(request, 'calculate/index.html', {})

def teammembers(request):
	return render(request,'calculate/teammembers.html', {})

def ourscience(request):
	return render(request, 'calculate/header.html', {})

def contactus(request):
	return render(request, 'calculate/contactus.html' ,{})

def calculate(request):
	return render(request, 'calculate/calculator.html' ,{})

def electricity(request):
	return render(request, 'calculate/calculator.html', {})

def vehicles(request):
	return render(request, 'calculate/calculator.html', {})


	



def electricity(request):
	return render(request, 'calculate/electricity.html', {})

def lpg(request):
	return render(request, 'calculate/lpg.html' , {})




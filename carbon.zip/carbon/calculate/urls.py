from django.conf.urls import url
from. import views

urlpatterns=[
 
 url(r'electricity' , views.electricity , name='electricity'),

 url(r'lpg' , views.lpg , name='lpg'),

 

 

]
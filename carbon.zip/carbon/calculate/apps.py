from django.apps import AppConfig


class CalculateConfig(AppConfig):
    name = 'calculate'

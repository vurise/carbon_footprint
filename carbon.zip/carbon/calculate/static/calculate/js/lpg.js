function model(){
	console.log("THIS IS JS");
}

function calculations(){
	console.log("THIS IS JS");
}
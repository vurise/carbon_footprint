let animate = 0;
let linkCounter = 0;

// Element Selection
let slideShowImg = new Image();
let slideShowImages = [ss1 = {source: "ss1.jpg", header: "Ahemdabad Air Pollution", text: "Despite various efforts by the government and the Supreme Court, the air quality post-Diwali across the country is extremely poor and hazardous, especially for children and senior citizens. The air quality index (AQI) in Ahmedabad was recorded at 213, which falls in 'poor' category on Tuesday.", link: "https://timesofindia.indiatimes.com/city/ahmedabad/scientists-warn-of-bad-air-quality-across-northwest-india/articleshow/69241864.cms"},
                       ss2 = {source: "ss3.jpg", header: "Acute Water Pollution", text: "Water pollution is one of the biggest issues facing India right now. As may be evident, untreated sewage is the biggest source of such form of pollution in India. There are other sources of pollution such as runoff from the agricultural sector as well as unregulated units that belong to the small-scale industry.", link: "https://www.mapsofindia.com/my-india/education/water-pollution-in-india-causes-effects-solutions"},
                       ss3 = {source: "ss2.jpg", header: "Delhi Air Pollution", text: "The air quality in Delhi, the capital of India, according to a WHO survey of 1600 world cities, is the worst of any major city in the world. Air pollution in India is estimated to kill 1.5 million people every year; it is the fifth largest killer in India.", link: "https://www.downtoearth.org.in/news/delhi-loses-80-lives-to-air-pollution-every-day-says-study-50222"},
                       ss4 = {source: "ss4.jpg", header: "Is Delhi Ready for E-Waste?", text: "By 2020, Delhi-National Capital will generate 1,50,000 metric tonnes (MT) of e-waste. According to latest findings by The Associated Chambers of Commerce of India (ASSOCHAM) Council on Climate Change & Environment.", link: "https://www.downtoearth.org.in/blog/waste/is-delhi-prepared-to-handle-its-e-waste--59504"}];
let slideShowWindow = document.getElementById('ssContainer');
let cardHeader = document.getElementById('cardHeader');
let cardText = document.getElementById('cardText');
let targetLink = document.getElementById('target-link');
let link = document.getElementsByClassName('nav-links');
let linkExpansion = document.getElementsByClassName('navExp');
let footprintDef = document.getElementById('carbon');
let calculatorDef = document.getElementById('calculator');
let solutionDef = document.getElementById('solution');
let exitElement = document.getElementById('exit');

for (let i = 0; i < link.length; i++){
    link[i].addEventListener('mouseenter', function() {
        for (let j = 0; j < linkExpansion.length; j++){
            if (i != j)
            linkExpansion[j].classList.add('blockData');
        }
        linkExpansion[i].classList.remove('blockData');
    });
}

for (let i = 0; i < linkExpansion.length; i++) {
    linkExpansion[i].addEventListener('mouseleave', function() {
        linkExpansion[i].classList.add('blockData');
    });
}
document.addEventListener('scroll', function () {
    if (window.scrollY > 10){
        footprintDef.style.display = "flex";
        footprintDef.classList.add('riseup');
    }
    if (window.scrollY > 500){
        console.log(window.scrollY);
        calculatorDef.style.display = "flex";
        calculatorDef.classList.add('riseup');
    }
    if (window.scrollY > 1000){
        console.log(window.scrollY);
        solutionDef.style.display = "flex";
        solutionDef.classList.add('riseup');
    }
    if (window.scrollY > 1600){
        console.log(window.scrollY);
        exitElement.style.opacity = 1;
    }
});

// Function Definitions
function slideShowAnimation() {
    animate++;
    if (animate > slideShowImages.length) {animate = 1;}
    slideShowImg.src = slideShowImages[animate-1].source;
    slideShowImg.classList.add('fade');
    slideShowImg.id = 'ssImage';
    cardHeader.textContent = slideShowImages[animate-1].header;
    cardText.textContent = slideShowImages[animate-1].text; 
    targetLink.setAttribute("href",slideShowImages[animate-1].link);
    slideShowWindow.appendChild(slideShowImg);
    setTimeout(slideShowAnimation,6000);
}

// Function Calls
slideShowAnimation();
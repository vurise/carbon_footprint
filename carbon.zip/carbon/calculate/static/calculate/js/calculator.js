let sideELPGImg = new Image();
sideELPGImg.style.maxWidth = "90%";
sideELPGImg.style.height = "auto";
const LPGWeight = 14.2;
const LPGDensity = 0.5525;
const LPGVol = 27.832;
const LPGEnergy = 0.02582;
const LPGEquivalent = 60;
const petrolConversionFactor = 2.392;
const dieselConversionFactor = 2.640;
const cngConversionFactor = 2.609;
const smallCabMileage = 26.12;
const largeCabMileage = 21.70;

let continueBtn = document.getElementById('continue');
let homeBtn = document.getElementById('homeTab');
let electricityBtn = document.getElementById('electricityTab');
let lpgBtn = document.getElementById('lpgTab');
let vehicleBtn = document.getElementById('vehicleTab');
let home = document.getElementById('calciWindow');
let electroLPGTab = document.getElementById('electroLPG');
let vehicleTab = document.getElementById('vehicle');
let electroImgDiv = document.getElementById('electroLPGImg');
let vehicleImgDiv = document.getElementById('vehicleImg');
let electroLPGTitle = document.getElementById('electroLPGTitle')
let electroLPGContent = document.getElementById('electroLPGContent');
let unitConsumption = document.getElementById('unitConsumption');
let modalInput = document.getElementsByClassName('consumptionInput');
let conversionFactorElement = document.getElementsByClassName('conversionFactor');
let referenceElement = document.getElementById('reference');
let footerResult = document.getElementById('footerResult');
let LPGCalculation = document.getElementById('extraCalculation');
let calculateBtn = document.getElementById('calculate');
let calculationExpBtn = document.getElementById('calculationExpansion');
let electroLPGResult = document.getElementById('CO2Equivalent');
let sliderCar = document.getElementById("myRangeCar");
let sliderBike = document.getElementById('myRangeBike');
let distanceCollection = document.getElementsByClassName('distanceConsumption');
let fuelType = document.getElementById('fuelType');
let cabChoice = document.getElementById('cabChoice');
let vehicleCalculate = document.getElementById('vehicleCalculate');
let vehicleExpansion = document.getElementById('vehicleExpansion');
let vehicleFooterResult = document.getElementById('vehicleFooterResult');
let fuel = "petrol";
let cab = "small";
let carMileage = 50;
let bikeMileage = 50;
let ans = 0;

const tabData = [
    electricity = {
        src: "electricity.jpg",
        alt: "Image of Bulb",
        title: "Electricity Consumption",
        text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda a eum nostrum enim mollitia nobis id quasi dolores! Eius laboriosam modi sapiente ipsa dolorem iure labore perspiciatis quidem veniam libero?",
        placeholder: "Enter units in kWh",
        conversionFactor: 0.82,
        referenceLink: "http://cea.nic.in/reports/others/thermal/tpece/cdm_co2/user_guide_ver10.pdf"
}, 
    lpg = {
        src: "lpg.jpg",
        alt: "Image of cylinder",
        title: "LPG Consumption",
        text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda a eum nostrum enim mollitia nobis id quasi dolores! Eius laboriosam modi sapiente ipsa dolorem iure labore perspiciatis quidem veniam libero?",
        placeholder: "Enter number of LPG cylinders",
        conversionFactor: 43.26,
        referenceLink: "https://www.iocl.com/products/LPGSpecifications.pdf"
}];
window.onload = showHome();

homeBtn.addEventListener('click',showHome);
continueBtn.addEventListener('click',showElectricity);
electricityBtn.addEventListener('click', showElectricity);
vehicleBtn.addEventListener('click', function () {
    home.style.display = "none";
    electroLPGTab.style.display = "none";
    vehicleTab.style.display = "flex";
})
lpgBtn.addEventListener('click', showLPG);
sliderCar.addEventListener('input', function () {
    let mileageCollection = document.getElementById('mileageRangeCar').children;
    carMileage = Number(this.value);
    for(let i = 0; i < mileageCollection.length; i++){
        if (mileageCollection[i].id == this.value){
            document.getElementById(this.value).style.backgroundColor = "rgba(0,98,204,0.4)";
            document.getElementById(this.value).style.borderRadius = "50%";
        }
        else {
            mileageCollection[i].style.backgroundColor = "transparent";
        }
    }
});
sliderBike.addEventListener('input', function () {
    let mileageCollection = document.getElementById('mileageRangeBike').children;
    bikeMileage = Number(this.value);
    for(let i = 0; i < mileageCollection.length; i++){
        if (mileageCollection[i].id == this.value + "b"){
            document.getElementById(this.value + "b").style.backgroundColor = "rgba(0,98,204,0.4)";
            document.getElementById(this.value + "b").style.borderRadius = "50%";
        }
        else {
            mileageCollection[i].style.backgroundColor = "transparent";
        }
    }
});
fuelType.addEventListener('input', function () {
    fuel = this.value;
});
cabChoice.addEventListener('input',function () {
    cab = this.value;
    console.log(cab);
});
vehicleCalculate.addEventListener('click', function() {
    if (fuel == "petrol"){
        ans += Number(distanceCollection[0].value)/carMileage * petrolConversionFactor;
    }
    else if (fuel == "diesel"){
        ans += Number(distanceCollection[0].value)/carMileage * dieselConversionFactor;
    }
    else{
        ans += Number(distanceCollection[0].value)/carMileage * cngConversionFactor;
    }
    ans += Number(distanceCollection[1].value)/bikeMileage * petrolConversionFactor;
    if (cab == "small"){
        ans += Number(distanceCollection[2].value)/smallCabMileage * cngConversionFactor;
    }
    else{
        ans += Number(distanceCollection[2].value)/largeCabMileage * cngConversionFactor;
    }
    vehicleFooterResult.classList.remove('blockData');
    vehicleFooterResult.style.fontSize = "2em";
    vehicleFooterResult.innerHTML = "<p>" + ans.toPrecision(6) + " Kg<sub>e</sub> of CO<sub>2</sub></p>";
    window.scrollBy(0,150);
});
vehicleExpansion.addEventListener('click', function () {
    let modalBody = document.getElementById('modalBody');
    modalBody.innerHTML = "<p><b>Distance Travelled:</b>   " + distanceCollection[0].value + "km (Car), " + distanceCollection[1].value + "km (Motorcycle), " + distanceCollection[2].value + "km (Cab)</p>" + 
                          "<p class='text-capitalize'><b>Fuel Used:</b> " + fuel + " (Car), " + "Petrol (Motorcycle), CNG (Cabs)</p>" + 
                          "<p><b>Mileage:   </b>" + carMileage + "kmpl (Car), " + bikeMileage + "kmpl (Motorcycle), " + smallCabMileage + "km/kg (Uber Go/ Ola Micro/ Ola Mini), " + largeCabMileage + "km/kg (Uber XL/ Ola Prime/Sedans)</p>" + 
                          "<p><b>Conversion Factors:</b> " + petrolConversionFactor + " (Petrol), " + dieselConversionFactor + " (Diesel), " + cngConversionFactor + " (CNG) kg<sub>e</sub> of CO<sub>2</sub> per ltr/kg</p>" + 
                          "<p><b>Method Used:</b> CO<sub>2</sub> Equivalent = (Distance Travelled/Mileage) &#10005; Conversion Factor" +
                          "<p class='text-warning'>Reference:   <a href = 'http://ecoscore.be/en/info/ecoscore/co2'>Ecoscore</a></p>";
});

function showHome() {  
    home.style.display = "flex";
    electroLPGTab.style.display = "none";
    vehicleTab.style.display = "none";
}
function showElectricity() {
    home.style.display = "none";
    vehicleTab.style.display = "none";
    electroLPGTab.style.display = "flex";
    unitConsumption.value = "";
    footerResult.classList.add('blockData');
    sideELPGImg.src = tabData[0].src;
    sideELPGImg.alt = tabData[0].alt;
    electroImgDiv.appendChild(sideELPGImg);
    electroLPGTitle.textContent = tabData[0].title;
    electroLPGContent.textContent = tabData[0].text;
    unitConsumption.setAttribute('placeholder',tabData[0].placeholder);
    referenceElement.setAttribute("href",tabData[0].referenceLink);
    referenceElement.textContent = ' Considering Coal as primary fuel for electricity generation.';
    for (let i = 0; i < conversionFactorElement.length; i++){
        conversionFactorElement[i].textContent = tabData[0].conversionFactor;
    }
    calculateBtn.addEventListener('click', function () {
        footerResult.classList.remove('blockData');
        footerResult.style.fontSize = "2em";
        footerResult.innerHTML = "<p>" + Number(eval(unitConsumption.value*tabData[0].conversionFactor)).toPrecision(6) + " Kg<sub>e</sub> of CO<sub>2</sub></p>";
        window.scrollBy(0,150);
    });
    calculationExpBtn.addEventListener('click', function () {
        for (let i = 0; i < modalInput.length; i++){
            modalInput[i].textContent = unitConsumption.value + ' Units';
        }
        electroLPGResult.textContent = Number(eval(unitConsumption.value*tabData[0].conversionFactor)).toPrecision(6);
        LPGCalculation.innerHTML = "";
    });
}
function showLPG() {
    home.style.display = "none";
    vehicleTab.style.display = "none";
    electroLPGTab.style.display = "flex";
    unitConsumption.value = "";
    footerResult.classList.add('blockData');
    sideELPGImg.src = tabData[1].src;
    sideELPGImg.alt = tabData[1].alt;
    electroImgDiv.appendChild(sideELPGImg);
    electroLPGTitle.textContent = tabData[1].title;
    electroLPGContent.textContent = tabData[1].text;
    unitConsumption.setAttribute('placeholder',tabData[1].placeholder);
    referenceElement.setAttribute("href",tabData[1].referenceLink);
    referenceElement.textContent = ' Considering density of LPG in India';
    for (let i = 0; i < conversionFactorElement.length; i++){
        conversionFactorElement[i].textContent = tabData[1].conversionFactor;
    }
    calculateBtn.addEventListener('click', function () {
        footerResult.classList.remove('blockData');
        footerResult.style.fontSize = "2em";
        footerResult.innerHTML = "<p>" + Number(eval(unitConsumption.value*tabData[1].conversionFactor)).toPrecision(6) + " Kg<sub>e</sub> of CO<sub>2</sub></p>";
        window.scrollBy(0,100);
    });
    calculationExpBtn.addEventListener('click', function () {
        for (let i = 0; i < modalInput.length; i++){
            modalInput[i].textContent = unitConsumption.value + ' Units';
        }
        electroLPGResult.textContent = Number(eval(unitConsumption.value*tabData[1].conversionFactor)).toPrecision(6);
        LPGCalculation.innerHTML = "<b>Weight</b> of 1 LPG Cylinder:   " + LPGWeight + " kg<br><b>Density</b> of LPG:  " + LPGDensity + "<br><b>Volume</b> of LPG:  " + LPGVol + " ltr<br>1 ltr of LPG releases <b>energy</b> equal to: " + LPGEnergy + " MJ<br><b>CO<sub>2</sub></b> equivalent of LPG:    " + LPGEquivalent + " Kg<sub>e</sub> CO<sub>2</sub><br>Therefore,   CO<sub>2</sub> Equivalent of 1 Cylinder: " + tabData[1].conversionFactor;    
    }); 
}
